import Button from "@mui/material/Button";

function Card(props) {
  return (
    <div>
      {props.data.map((item, index) => (
        <div
          style={{
            border: "1px solid black",
            width: "200px",
            display: "inline-block",
            margin: "10px 10px",
          }}
        >
          <img src={props.data[index].img} width="200px" height="200px"></img>
          <h4>{props.data[index].name}</h4>
          <p>{props.data[index].price}</p>
        </div>
      ))}
      <br />
      <br />
      <br />

      <Button
        onClick={() => console.log("hello")}
        variant="contained"
        fullWidth="true"
      >
        Contained
      </Button>
    </div>
  );
}

export default Card;
